package com.example.medhist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth mAuth;
    private CardView medicineSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Set Title
        setTitle("Home Page");

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        medicineSearch= findViewById(R.id.medicineSearchId);
        medicineSearch.setOnClickListener(this);

    }



// Create Option Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater= getMenuInflater();

        menuInflater.inflate(R.menu.menu_item,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.profileId){
            Toast.makeText(MainActivity.this,"Profile",Toast.LENGTH_SHORT).show();
        }
        else  if(item.getItemId()==R.id.logoutId){

            Toast.makeText(MainActivity.this,"Logout",Toast.LENGTH_SHORT).show();
            FirebaseAuth.getInstance().signOut();
            send_to_startActivity();

        }
        else if(item.getItemId()==R.id.aboutId){

            Toast.makeText(MainActivity.this,"About",Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }


   @Override
    public void onStart() {
        super.onStart();
        // Check if user is sign in or not. If not then go to the Start_Activity.java(Activity) by the send_to_startActivity() Method
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if(currentUser==null){

            send_to_startActivity();
        }

    }

    private void send_to_startActivity() {

        Intent intent= new Intent(MainActivity.this,Start_Activity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.medicineSearchId){
            Intent intent= new Intent(MainActivity.this,Search_Medicine.class);
            startActivity(intent);
        }
    }
}

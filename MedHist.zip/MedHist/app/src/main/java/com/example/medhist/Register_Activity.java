package com.example.medhist;

import android.Manifest;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.HashMap;

public class Register_Activity extends AppCompatActivity {

    private EditText nameEditText,ageEditText,weightEdittext,mobileEditText;
    private CircularImageView profileImageView;
    private Button registerButton;
    private RadioGroup genderRadioGroup,diabetesRadioGroup,liverRadioGroup;
    private RadioButton gender_radioButton,diabetes_radioButton,liver_radioButton;
    private String[] bloodGroupName;
    private Spinner bloodGroup;

    //storage variable and code
    private final static int CAMERA_REQUEST_CODE= 200;
    private final static int STORAGE_REQUEST_CODE= 400;
    private final static int IMAGE_PICK_GALLERY_CODE= 1000;
    private final static int IMAGE_PICK_CAMERA_CODE= 1001;

    String cameraPermission[];
    String storagePermission[];

    Uri image_uri;

    //database Variable

    private DatabaseReference databaseReference;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_);

        //hiding action bar/toolbar for specific activity
        getSupportActionBar().hide();



        //camera permission
        cameraPermission= new String[]{Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE};

        //storage permission
        storagePermission= new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

        //storage initilize
        storageReference= FirebaseStorage.getInstance().getReference();

        //find section

        profileImageView= findViewById(R.id.registerImageViewId);
        nameEditText= findViewById(R.id.registerNameId);
        ageEditText= findViewById(R.id.registerAgeId);
        weightEdittext= findViewById(R.id.registerWeightId);
        genderRadioGroup= findViewById(R.id.registerGenderId);
        bloodGroup= findViewById(R.id.bloodGroupId);
        diabetesRadioGroup= findViewById(R.id.diabetesId);
        liverRadioGroup= findViewById(R.id.liverId);
        mobileEditText= findViewById(R.id.registrationMobileId);
        registerButton= findViewById(R.id.registerButtonId);


        //get string(blood group Name) from string.xml
        bloodGroupName= getResources().getStringArray(R.array.blood_group);

        ArrayAdapter<String> adapter= new ArrayAdapter<String>(Register_Activity.this,R.layout.blood_group,R.id.sampleTextId,bloodGroupName);
        bloodGroup.setAdapter(adapter);

        //set on click listrener:

        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ImageImport();
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String reg_image,reg_name,reg_age,reg_weight,reg_gender,reg_blood,reg_diabetes,reg_liver,reg_mobile;

                int gender_select,blood_select,diabetes_select,liver_select;

                gender_select=genderRadioGroup.getCheckedRadioButtonId();
                diabetes_select= diabetesRadioGroup.getCheckedRadioButtonId();
                liver_select= liverRadioGroup.getCheckedRadioButtonId();

                gender_radioButton=findViewById(gender_select);
                diabetes_radioButton= findViewById(diabetes_select);
                liver_radioButton= findViewById(liver_select);


                reg_name= nameEditText.getText().toString();
                reg_age= ageEditText.getText().toString().trim();
                reg_weight= weightEdittext.getText().toString().trim();
                reg_gender=gender_radioButton.getText().toString();
                reg_blood=bloodGroup.getSelectedItem().toString();
                reg_diabetes= diabetes_radioButton.getText().toString();
                reg_liver= liver_radioButton.getText().toString();
                reg_mobile= mobileEditText.getText().toString().trim();

                if(!TextUtils.isEmpty(reg_name) && !TextUtils.isEmpty(reg_age) && !TextUtils.isEmpty(reg_weight) &&
                        !TextUtils.isEmpty(reg_gender) && !TextUtils.isEmpty(reg_blood) && !TextUtils.isEmpty(reg_diabetes) &&
                        !TextUtils.isEmpty(reg_liver)  ){

                    user_registration(reg_name,reg_age,reg_weight,reg_gender,reg_blood,reg_diabetes,reg_liver,reg_mobile);

                }

                else{
                    Toast.makeText(Register_Activity.this,"Incomplete Mandatory Field",Toast.LENGTH_SHORT).show();
                }

            }
        });


    }

    private void ImageImport() {

        String[] item= {"Camera"," Gallery"};

        AlertDialog.Builder dialoge = new AlertDialog.Builder(this);
        dialoge.setTitle("Select Image");
        dialoge.setItems(item, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if(which==0){
                    //camera option clicked
                    if(!checkCameraPermission()){
                        //camera permission nor allowd, request it
                        requestCameraPermission();
                    }
                    else {
                        //permission allowd, take picture
                        pickCamera();
                    }
                }

                if(which==1){
                    //gallery option clicked
                    if(!checkStoragePermission()){
                        //storage permission nor allowd, request it
                        requestStoragePermission();
                    }
                    else {
                        //permission allowd, take picture
                        pickGallery();

                    }
                }
            }
        });
        dialoge.create().show();
    }

    private void pickGallery() {

        Intent galleryIntent= new Intent();
        galleryIntent.setType("image/*");
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(galleryIntent,"SELECT IMAGE"),IMAGE_PICK_GALLERY_CODE);

    }

    private void pickCamera() {

        //Intent to take image from camera and it also saved storage
        ContentValues values= new ContentValues();
        values.put(MediaStore.Images.Media.TITLE,"NewPic");//title of pic
        values.put(MediaStore.Images.Media.DESCRIPTION,"Image to text");//Description
        image_uri= getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        Intent cameraIntent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,image_uri);
        startActivityForResult(cameraIntent,IMAGE_PICK_CAMERA_CODE);
    }

    private void requestStoragePermission() {

        ActivityCompat.requestPermissions(this,storagePermission,STORAGE_REQUEST_CODE);
    }

    private boolean checkStoragePermission() {

        boolean result= ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result;
    }

    private void requestCameraPermission() {

        ActivityCompat.requestPermissions(this,cameraPermission,CAMERA_REQUEST_CODE);

    }

    private boolean checkCameraPermission() {

        boolean result= ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                ==(PackageManager.PERMISSION_GRANTED);
        boolean result1= ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }

    //handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case CAMERA_REQUEST_CODE:
                if(grantResults.length>0){
                    boolean cameraAccecpted= grantResults[0]==
                            PackageManager.PERMISSION_GRANTED;
                    boolean writeStorageAccecpted= grantResults[0]==
                            PackageManager.PERMISSION_GRANTED;

                    if(cameraAccecpted && writeStorageAccecpted){
                        pickCamera();
                    }
                }
                else {
                    Toast.makeText(this,"Permission Denide",Toast.LENGTH_SHORT).show();
                }
                break;
            case STORAGE_REQUEST_CODE:
                if(grantResults.length>0){

                    boolean writeStorageAccecpted= grantResults[0]==
                            PackageManager.PERMISSION_GRANTED;

                    if(writeStorageAccecpted){
                        pickGallery();
                    }
                }
                else {
                    Toast.makeText(this,"Permission Denide",Toast.LENGTH_SHORT).show();
                }
                break;

        }
    }

    //handle Image result:


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK){



        }
    }

    private void user_registration(String reg_name, String reg_age, String reg_weight, String reg_gender, String reg_blood, String reg_diabetes, String reg_liver, String reg_mobile) {

        FirebaseUser current_user= FirebaseAuth.getInstance().getCurrentUser();
        String uid= current_user.getUid();

        databaseReference= FirebaseDatabase.getInstance().getReference().child("Users").child(uid);

        HashMap<String,String> userMap= new HashMap<>();
        userMap.put("image","no image");
        userMap.put("name",reg_name);
        userMap.put("age",reg_age);
        userMap.put("weight",reg_weight);
        userMap.put("gender",reg_gender);
        userMap.put("blood",reg_blood);
        userMap.put("diabetes problem",reg_diabetes);
        userMap.put("liver problem",reg_liver);
        userMap.put("mobile",reg_mobile);

        databaseReference.setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if(task.isSuccessful()){

                    Intent intent= new Intent(Register_Activity.this,MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
                else {

                    Toast.makeText(Register_Activity.this,"Registration Failed",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }


}

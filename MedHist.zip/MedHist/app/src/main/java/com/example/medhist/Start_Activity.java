package com.example.medhist;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Start_Activity extends AppCompatActivity implements View.OnClickListener {

    private CardView googleLogin,facebookLogin;

    private GoogleSignInClient googleApiClient;
    private static final int RC_SIGN_IN = 1;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener authStateListener;

    private FirebaseUser firebaseUser;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //hiding the title bar for specific activity
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //hiding action bar/toolbar for specific activity
        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_);

        //initilize the Firebase Authentication
        mAuth= FirebaseAuth.getInstance();

        //find section
        googleLogin= findViewById(R.id.googleLoginId);
        facebookLogin= findViewById(R.id.facebookLoginId);


        //set On click Listener
        googleLogin.setOnClickListener(this);
        facebookLogin.setOnClickListener(this);


        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleApiClient= GoogleSignIn.getClient(this,gso);

        //Check user Loged in or Not
//        authStateListener= new FirebaseAuth.AuthStateListener() {
//            @Override
//            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
//
//                if(firebaseAuth.getCurrentUser()!=null){
//                    user_have_or_not();
//                }
//            }
//        };
    }

    @Override
    protected void onStart() {
        super.onStart();
//        mAuth.addAuthStateListener(authStateListener);
        if(mAuth.getCurrentUser()!=null)
        {
            user_have_or_not();
            Toast.makeText(Start_Activity.this,"User",Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(Start_Activity.this,"NUll User",Toast.LENGTH_SHORT).show();
        }

    }

    // On click method
    @Override
    public void onClick(View v) {
        if(v.getId()== R.id.googleLoginId){

            signIn();
        }
        else if(v.getId()==R.id.facebookLoginId){

            Toast.makeText(Start_Activity.this,"facebook",Toast.LENGTH_SHORT).show();
        }
    }

    //google signin Method

    private void signIn() {
        Intent signInIntent = googleApiClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Toast.makeText(Start_Activity.this,""+e,Toast.LENGTH_SHORT).show();

                // ...
            }
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {
        //Log.d(TAG, "firebaseAuthWithGoogle:" + acct.getId());

        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            //Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(Start_Activity.this,"Login Success",Toast.LENGTH_SHORT).show();
                            user_have_or_not();



                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(Start_Activity.this,"Login Failed",Toast.LENGTH_SHORT).show();

                        }

                        // ...
                    }
                });


    }

    public void user_have_or_not(){

        String currentUid= mAuth.getCurrentUser().getUid();
        DatabaseReference mRef = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUid);
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    go_to_main();
                }
                else
                {
                    go_to_registration();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }

    private void go_to_registration() {

        Intent intent= new Intent(Start_Activity.this,Register_Activity.class);
        startActivity(intent);
        finish();
    }

    private void go_to_main() {

        Intent intent= new Intent(Start_Activity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }


}
